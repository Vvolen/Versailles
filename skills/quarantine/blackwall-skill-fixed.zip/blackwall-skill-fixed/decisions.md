# Blackwall Decisions Log

> This file tracks key decisions and their rationale.
> Last updated: 2026-01-01

## Architecture Decisions

### ADR-001: Supabase as Memory Backend
**Date**: 2025 (Project inception)
**Decision**: Use Supabase for Blackwall memory infrastructure
**Rationale**: 
- Real-time subscriptions built-in
- PostgreSQL with pgvector for embeddings
- Edge Functions for serverless compute
- Row-level security for multi-tenant support
**Status**: Active ✅

### ADR-002: HNSW Vector Index
**Date**: 2025
**Decision**: Use HNSW (Hierarchical Navigable Small World) for vector similarity search
**Rationale**:
- O(log n) search complexity vs O(n) for brute force
- Sub-millisecond retrieval even at scale
- Good balance of speed and recall accuracy
**Status**: Active ✅

### ADR-003: Hybrid BM25 + Semantic Search
**Date**: 2025
**Decision**: Combine keyword (BM25) and semantic (vector) search
**Rationale**:
- BM25 catches exact matches that semantic might miss
- Semantic catches meaning that keywords miss
- Combined approach has highest relevance scores
**Status**: Active ✅

### ADR-004: Temporal Decay Scoring
**Date**: 2025
**Decision**: Weight memory relevance by recency
**Rationale**:
- Recent context often more relevant
- Prevents old irrelevant memories cluttering context
- Configurable decay rate for different memory types
**Status**: Active ✅

## Tech Stack Decisions

### TSD-001: React 18+ for Dashboard
**Date**: 2026-01-01
**Decision**: Use React 18 with TypeScript for Blackwall Dashboard
**Rationale**:
- Concurrent rendering for smooth UX
- Strong typing prevents runtime errors
- Rich ecosystem (Framer Motion, D3, etc.)
- Team familiarity
**Status**: Planned 📋

### TSD-002: Tailwind CSS for Styling
**Date**: 2026-01-01
**Decision**: Use Tailwind CSS with custom dark mode configuration
**Rationale**:
- Rapid prototyping
- Consistent design system
- Works well with AI code generation
- Easy to maintain Eden aesthetic
**Status**: Planned 📋

### TSD-003: Framer Motion for Animations
**Date**: 2026-01-01
**Decision**: Use Framer Motion for all dashboard animations
**Rationale**:
- Spring physics for natural feel
- Layout animations for morphing panels
- Shared element transitions for Polly Pockets aesthetic
- React-native integration
**Status**: Planned 📋

### TSD-004: Thesys C1 for Generative UI
**Date**: 2026-01-01
**Decision**: Integrate Thesys C1 for AI-generated interface components
**Rationale**:
- Stateful React components from LLM output
- Custom theming support
- Action handlers for interactive AI responses
**Status**: Planned 📋

### TSD-005: ElevenLabs for Agent Voices
**Date**: 2026-01-01
**Decision**: Use ElevenLabs multi-voice API for agent personification
**Rationale**:
- High-quality voice synthesis
- Multi-voice support in single conversation
- XML markup for voice switching
- 75ms latency with Flash model
**Status**: Planned 📋

## Design Decisions

### DD-001: Eden Aesthetic
**Date**: 2026-01-01
**Decision**: Follow Eden design language
**Rationale**:
- Dark mode (#0a0a0a base)
- Grain texture overlay
- Backdrop blur panels
- Serif + sans typography
- Already proven visually stunning
**Status**: Planned 📋

### DD-002: Polly Pockets Interaction Model
**Date**: 2026-01-01
**Decision**: Implement expandable "worlds" for agent panels
**Rationale**:
- Compact overview, detailed on demand
- Natural morphing animations
- Multiple interconnected views
- Matches mental model of agent ecosystem
**Status**: Planned 📋

### DD-003: Seven Agent Roster
**Date**: 2026-01-01
**Decision**: Visualize 7 core agents with distinct identities
**Agents**:
1. Super Ninja (Cerebras) - Builder, direct
2. Claude Opus - Analyst, warm
3. Blackwall Core - Memory, omniscient
4. Manus AI - Executor, efficient
5. n8n - Workflow, methodical
6. Flowise - Flow, creative
7. Cerebras - Speed, powerful
**Status**: Planned 📋

## Process Decisions

### PD-001: SPARC Methodology for Complex Builds
**Date**: 2026-01-01
**Decision**: Use SPARC (Specification, Pseudocode, Architecture, Refinement, Completion) for dashboard build
**Rationale**:
- 84.8% SWE-Bench solve rate
- Structured phases prevent over-engineering
- Test-driven approach catches issues early
**Status**: Active ✅

### PD-002: Context Engineering over Prompt Engineering
**Date**: 2026-01-01
**Decision**: Focus on providing complete context rather than clever prompts
**Rationale**:
- "Agent failures aren't model failures - they're context failures"
- Complete world context enables one-shot execution
- Reduces iteration cycles
**Status**: Active ✅

### PD-003: Skills-Based Learning Loop
**Date**: 2026-01-01
**Decision**: Implement continuous learning through updatable skill files
**Rationale**:
- Knowledge compounds across sessions
- Failures and successes both documented
- Interpretable (plain English)
- Easy to correct mistakes
**Status**: Active ✅

---

## Decision Template

When documenting new decisions:

```markdown
### [Category]-[Number]: [Short Title]
**Date**: [YYYY-MM-DD]
**Decision**: [Clear statement of what was decided]
**Rationale**: 
- [Reason 1]
- [Reason 2]
- [Reason 3]
**Alternatives Considered**: [Optional - what else was evaluated]
**Status**: Active ✅ | Planned 📋 | Deprecated ❌ | Superseded 🔄
```

---

## Pending Decisions

- [ ] Voice assignment per agent (which ElevenLabs voice for each?)
- [ ] Network graph library (D3.js vs react-force-graph vs custom?)
- [ ] Deployment target (Vercel vs Cloudflare vs self-hosted?)
- [ ] Authentication approach for dashboard
