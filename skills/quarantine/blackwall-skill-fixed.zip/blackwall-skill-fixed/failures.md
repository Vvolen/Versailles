# Blackwall Failures Log

> This file documents what NOT to do. Every failure is a lesson.
> Last updated: 2026-01-01

## Anti-Patterns to Avoid

### Prompt Engineering Failures

#### ❌ Over-Engineering Prompts
**What happened**: Gave Claude too many instructions, alternatives, and hedging language
**Why it failed**: Model got confused, output was generic and unfocused
**Lesson**: One clear path is better than five optional paths

#### ❌ Placeholders in Code
**What happened**: Used "// rest of code remains the same..."
**Why it failed**: Subsequent edits couldn't find the right location
**Lesson**: ALWAYS provide FULL file contents

#### ❌ Assuming Context
**What happened**: Didn't include file paths, didn't read existing code
**Why it failed**: Model hallucinated structure that didn't exist
**Lesson**: Read files first, verify before writing

### Technical Failures

#### ❌ Supabase Realtime Without Cleanup
**What happened**: Subscribed to channels but didn't unsubscribe on unmount
**Why it failed**: Memory leaks, duplicate subscriptions, weird state bugs
**Lesson**: ALWAYS `supabase.removeChannel(channel)` in cleanup

#### ❌ Framer Motion Without AnimatePresence
**What happened**: Exit animations didn't work
**Why it failed**: AnimatePresence wrapper is required for unmount animations
**Lesson**: Wrap conditional renders in AnimatePresence

#### ❌ D3 Force Simulation Without Tick Handler
**What happened**: Nodes didn't move, graph was static
**Why it failed**: `simulation.on("tick", ...)` is what updates DOM
**Lesson**: Always implement the tick handler for force simulations

### Process Failures

#### ❌ Not Using Plan Mode
**What happened**: Jumped straight into coding without planning
**Why it failed**: Built wrong thing, had to refactor multiple times
**Lesson**: Use Plan Mode (Shift+Tab twice) to clarify before building

#### ❌ Single Message for Everything
**What happened**: Tried to do complex multi-step task in one prompt
**Why it failed**: Lost context, made errors in later steps
**Lesson**: Complex tasks need structured phases (SPARC methodology)

#### ❌ No Verification Before "Done"
**What happened**: Declared task complete without testing
**Why it failed**: Production had bugs, had to debug retroactively
**Lesson**: Always verify: `npm run build`, test subscriptions, check deployment

### Memory System Failures

#### ❌ Token-Heavy Memory Retrieval
**What happened**: Retrieved too many memory fragments into context
**Why it failed**: Consumed excessive context window, degraded performance
**Lesson**: Be selective with memory retrieval, use relevance scoring

#### ❌ No Temporal Decay
**What happened**: Old irrelevant memories kept surfacing
**Why it failed**: Cluttered context with outdated information
**Lesson**: Implement temporal decay scoring for memory relevance

---

## Failure Template

When documenting new failures, use this format:

```markdown
#### ❌ [Short Description]
**What happened**: [Describe the action taken]
**Why it failed**: [Root cause analysis]
**Lesson**: [Actionable insight for future]
```

---

## Recovery Patterns

When encountering these failures again:

1. **Over-engineering** → Simplify, one path, clear criteria
2. **Placeholder code** → Regenerate full file
3. **Missing context** → Read file first, verify structure
4. **Memory leak** → Add cleanup to useEffect
5. **No animations** → Check AnimatePresence wrapper
6. **Static graph** → Verify tick handler exists
7. **Wrong build** → Stop, use Plan Mode, clarify
8. **Untested** → Run verification checklist before declaring done
