---
name: blackwall-memory
description: Persistent memory and learning system for Project Blackwall. Enables remembering context, learnings, failures, and successes across sessions. Invoke when working on Blackwall tasks, recalling past decisions, conducting retrospectives, or when encountering errors to document.
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - WebSearch
---

# Blackwall Memory Skill

## When to Invoke
- Any mention of "Blackwall", "memory system", "what did we decide", "remember"
- Start of any coding session related to Blackwall
- End of sessions for retrospective updates
- When encountering errors to document
- When discovering patterns to preserve

## Supabase Connection
```
URL: https://ynbxlpthxqjkkrkvkkpl.supabase.co
Table: memory_fragments (NOT 'memory')
Key functions: get_session_context(), hybrid_search_memory(), start_agent_session()
```

## Progressive Disclosure
Load these files as needed:
- `learnings.md` - Accumulated insights
- `failures.md` - What NOT to do
- `successes.md` - Proven approaches
- `decisions.md` - Key decisions
- `context.md` - Current state

## Learning Loop Protocol

### Session Start
1. Call `get_session_context('claude_code')` 
2. Load relevant context from memory files
3. Surface past experiments and known failures

### During Session
- Errors → Document in `failures.md`
- Solutions → Document in `successes.md`
- Decisions → Document in `decisions.md`
- Update `context.md` with current state

### Session End (Retrospective)
1. Review conversation, extract learnings
2. Update all memory files
3. Save critical insights to Supabase

## Quick Commands
- `/recall [topic]` - Search memory
- `/learn [insight]` - Add learning
- `/fail [description]` - Document failure
- `/success [description]` - Document success
- `/retro` - Full retrospective
- `/status` - Current state

## Memory Anchors (How Nick Thinks About It)
- **Blackwall** = Filing Cabinet (documents, facts)
- **ReasoningBank** = Journal (patterns, lessons)
- **RuVector** = Librarian (gets faster at finding)
