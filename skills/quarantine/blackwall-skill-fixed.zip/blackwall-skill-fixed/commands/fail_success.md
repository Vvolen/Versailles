# /fail Command

## Purpose
Quickly document a failure or anti-pattern discovered during the session.

## Usage
```
/fail [description]
/fail "Tried to use D3 append() with React - conflicts with virtual DOM"
```

## Behavior
When invoked, Claude should:

1. **Parse the failure description**

2. **Analyze root cause** from conversation context

3. **Generate lesson** - actionable insight to prevent recurrence

4. **Append to failures.md** using template:
   ```markdown
   #### ❌ [Short Title]
   **What happened**: [Description from command]
   **Why it failed**: [Root cause analysis]
   **Lesson**: [Actionable prevention]
   ```

5. **Confirm**:
   ```
   ❌ Failure documented!
   
   Issue: [Short title]
   Root Cause: [Why it failed]
   Lesson: [How to avoid]
   
   Added to failures.md
   ```

## Example

```
> /fail "Animation janky when animating width directly"

❌ Failure documented!

Issue: Direct Width Animation Jank
Root Cause: Animating width triggers layout recalculation every frame
Lesson: Use transform: scaleX() instead, or animate maxWidth with will-change

Added to failures.md
```

---

# /success Command

## Purpose
Quickly document a successful pattern or approach worth reusing.

## Usage
```
/success [description]
/success "useCallback with Supabase subscription prevents unnecessary re-renders"
```

## Behavior
When invoked, Claude should:

1. **Parse the success description**

2. **Identify why it worked** from conversation context

3. **Generate reuse guidance** - how to apply this in future

4. **Append to successes.md** using template:
   ```markdown
   #### ✅ [Short Title]
   **What we did**: [Description from command]
   **Why it worked**: [Mechanism explanation]
   **Reuse**: [How to apply in future]
   ```

5. **Confirm**:
   ```
   ✅ Success documented!
   
   Pattern: [Short title]
   Mechanism: [Why it worked]
   Reuse: [Future application]
   
   Added to successes.md
   ```

## Example

```
> /success "Wrapping Supabase channel in useRef preserved reference across re-renders"

✅ Success documented!

Pattern: useRef for Supabase Channel
Mechanism: useRef maintains stable reference, preventing channel recreation on re-render
Reuse: Always wrap external subscriptions/connections in useRef, not useState

Added to successes.md
```

---

## Notes for Both Commands

- Can be used anytime during session, not just at end
- Quick capture is better than forgetting
- Full retrospective (/retro) will consolidate and organize
- These become training data for future sessions
