# /status Command

## Purpose
Display current project state and what's needed to continue.

## Usage
```
/status
```

## Behavior
When invoked, Claude should:

1. **Read context.md** for current state

2. **Display dashboard**:
   ```
   ┌─────────────────────────────────────────────────────────────┐
   │                    BLACKWALL STATUS                         │
   ├─────────────────────────────────────────────────────────────┤
   │  Current Focus   │ [Active workstream from context.md]     │
   │  Phase           │ [Current phase]                          │
   │  Priority        │ [HIGH/MEDIUM/LOW]                        │
   ├─────────────────────────────────────────────────────────────┤
   │  INFRASTRUCTURE                                              │
   │  Memory System   │ [Status]                                  │
   │  Edge Functions  │ [Status]                                  │
   │  Vector Index    │ [Status]                                  │
   ├─────────────────────────────────────────────────────────────┤
   │  AGENTS                                                      │
   │  Super Ninja     │ [Status]                                  │
   │  Claude Opus     │ [Status]                                  │
   │  Blackwall Core  │ [Status]                                  │
   │  [etc...]        │                                           │
   ├─────────────────────────────────────────────────────────────┤
   │  NEXT ACTIONS                                                │
   │  1. [Next step 1]                                            │
   │  2. [Next step 2]                                            │
   │  3. [Next step 3]                                            │
   └─────────────────────────────────────────────────────────────┘
   ```

3. **Highlight blockers** if any

4. **Suggest immediate action** based on state

## Example Output

```
> /status

┌─────────────────────────────────────────────────────────────┐
│                    BLACKWALL STATUS                         │
├─────────────────────────────────────────────────────────────┤
│  Current Focus   │ Dashboard Build                          │
│  Phase           │ Research Complete → Ready for Build      │
│  Priority        │ 🔴 HIGH                                   │
├─────────────────────────────────────────────────────────────┤
│  INFRASTRUCTURE                                              │
│  Memory System   │ ✅ OPERATIONAL                            │
│  Edge Functions  │ ✅ 11 cron jobs active                    │
│  Vector Index    │ ✅ HNSW indexed                           │
│  Hybrid Search   │ ✅ BM25 + semantic                        │
├─────────────────────────────────────────────────────────────┤
│  AGENTS                                                      │
│  Super Ninja     │ 🟢 Ready (Cerebras wafer-scale)          │
│  Claude Opus     │ 🟢 Active (this conversation)            │
│  Blackwall Core  │ 🟢 Operational                           │
│  Manus AI        │ 🟡 Planned                               │
│  n8n             │ 🟡 MCP integration pending               │
│  Flowise         │ 🟡 Planned                               │
│  Cerebras        │ 🟢 Ready (3000 tok/s)                    │
├─────────────────────────────────────────────────────────────┤
│  SKILL MEMORY                                                │
│  Learnings       │ 47 insights captured                     │
│  Failures        │ 12 anti-patterns documented              │
│  Successes       │ 23 proven patterns                       │
│  Decisions       │ 15 ADRs logged                           │
├─────────────────────────────────────────────────────────────┤
│  NEXT ACTIONS                                                │
│  1. Finalize spec document for Super Ninja                  │
│  2. Deploy dashboard via autonomous one-shot                │
│  3. Integrate Blackwall memory visualization                │
└─────────────────────────────────────────────────────────────┘

💡 Recommended: Start with /recall dashboard to load relevant context,
   then proceed with spec finalization.
```

## Notes
- Pull live data from context.md
- Update context.md if stale
- Use at session start to orient
- Use mid-session to check progress
