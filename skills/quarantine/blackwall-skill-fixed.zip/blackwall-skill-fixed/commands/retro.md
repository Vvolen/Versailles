# /retro Command

## Purpose
Run a full retrospective at the end of a session to extract learnings and update skill files.

## Usage
```
/retro
```

## Behavior
When invoked, Claude should:

1. **Review the entire conversation** from this session

2. **Extract learnings** - What new insights emerged?
   - Technical patterns discovered
   - Architectural decisions made
   - New tools or approaches learned
   - Meta-insights about process

3. **Identify failures** - What went wrong?
   - Errors encountered
   - Approaches that didn't work
   - Anti-patterns identified
   - Root causes analyzed

4. **Document successes** - What worked?
   - Patterns that succeeded
   - Approaches to reuse
   - Code snippets worth saving
   - Process improvements

5. **Update skill files**:
   - Append to `learnings.md` with date header
   - Append to `failures.md` using template
   - Append to `successes.md` using template
   - Update `decisions.md` if decisions were made
   - Update `context.md` with current state

6. **Report summary** to user:
   ```
   📝 Retrospective Complete
   
   Learnings added: X
   Failures documented: Y
   Successes recorded: Z
   Decisions logged: W
   
   Context updated. Ready for next session.
   ```

## Example Output

After running /retro, Claude might update files like:

### learnings.md addition:
```markdown
## Session Log

### 2026-01-01 - Dashboard Build Session
- Discovered that Framer Motion `layoutId` must be unique across components
- Supabase Realtime requires explicit unsubscribe or memory leaks occur
- Eden aesthetic grain overlay needs `pointer-events: none` to not block clicks
```

### failures.md addition:
```markdown
#### ❌ Network Graph Without Cleanup
**What happened**: D3 force simulation kept running after component unmount
**Why it failed**: No cleanup in useEffect, simulation consumed CPU
**Lesson**: Always `simulation.stop()` in cleanup function
```

### successes.md addition:
```markdown
#### ✅ Spring Animation Parameters
**What we did**: Used `stiffness: 100, damping: 30` for all transitions
**Why it worked**: Natural, satisfying motion that matches Eden aesthetic
**Reuse**: Apply these exact values as default spring config
```

## Self-Improvement
After 5 retrospectives, also evaluate:
- Are these templates still effective?
- Should new categories be added?
- Is the skill.md description still accurate?
- Update the skill itself if needed.
