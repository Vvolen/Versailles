# /learn Command

## Purpose
Quickly add a new learning to the skill memory without running full retrospective.

## Usage
```
/learn [insight]
/learn "Supabase Realtime filters can narrow subscription scope significantly"
/learn "D3 force simulation needs explicit stop() on unmount"
```

## Behavior
When invoked, Claude should:

1. **Parse the insight** from the command

2. **Categorize** the learning:
   - Technical (code patterns, library usage)
   - Process (workflow improvements)
   - Design (aesthetic, UX insights)
   - Architecture (system design)
   - Meta (insights about learning itself)

3. **Append to learnings.md** with:
   - Timestamp
   - Category tag
   - The insight
   - Optional: Related context from current conversation

4. **Confirm** the addition:
   ```
   💡 Learning captured!
   
   Category: [Technical/Process/Design/etc.]
   Insight: "[the insight]"
   
   Added to learnings.md
   ```

## Example

```
> /learn "Claude Flow batch operations in single message are 6x faster"

💡 Learning captured!

Category: Technical
Insight: "Claude Flow batch operations in single message are 6x faster"

Added to learnings.md under "Agent Orchestration Insights"
```

## Format in learnings.md

```markdown
### Quick Learnings

#### 2026-01-01
- **[Technical]** Claude Flow batch operations in single message are 6x faster
- **[Process]** Plan Mode (Shift+Tab twice) should be used before any complex build
- **[Design]** Grain overlay needs `pointer-events: none`
```

## Notes
- Keep insights concise but complete
- Include "why" when possible, not just "what"
- Tag for easy filtering later
