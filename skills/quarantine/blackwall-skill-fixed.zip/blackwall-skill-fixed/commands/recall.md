# /recall Command

## Purpose
Search skill memory for relevant past learnings, decisions, or context.

## Usage
```
/recall [topic]
/recall framer motion
/recall supabase errors
/recall design decisions
```

## Behavior
When invoked, Claude should:

1. **Parse the topic** from the command

2. **Search across all skill files**:
   - `learnings.md` - For insights on the topic
   - `failures.md` - For known anti-patterns
   - `successes.md` - For proven approaches
   - `decisions.md` - For related decisions
   - `context.md` - For current state

3. **Rank results** by relevance to topic

4. **Present findings** in structured format:
   ```
   🔍 Recall: "[topic]"
   
   📚 Learnings:
   - [Relevant insight 1]
   - [Relevant insight 2]
   
   ❌ Known Failures:
   - [Anti-pattern to avoid]
   
   ✅ Proven Approaches:
   - [What works]
   
   📋 Related Decisions:
   - [ADR-XXX: Decision title]
   
   💡 Recommendation: [Synthesized advice based on findings]
   ```

## Example

```
> /recall animations

🔍 Recall: "animations"

📚 Learnings:
- Spring physics: stiffness 100, damping 30 for natural feel
- Use `layout` prop for smooth layout animations
- `layoutId` enables shared element transitions
- `AnimatePresence` required for mount/unmount animations

❌ Known Failures:
- Framer Motion without AnimatePresence: Exit animations didn't work
- Missing layoutId: Shared element transitions failed silently

✅ Proven Approaches:
- Spring Animation Parameters: stiffness 100, damping 30
- Eden Aesthetic: Combine with grain overlay and backdrop blur

📋 Related Decisions:
- TSD-003: Use Framer Motion for all dashboard animations

💡 Recommendation: For the Polly Pockets morphing effect, use 
   layoutId on both collapsed and expanded states with spring 
   physics. Wrap in AnimatePresence for exit animations.
```

## Notes
- If no results found, say so clearly
- Suggest related topics that might help
- Offer to search Blackwall memory system if local skill files insufficient
