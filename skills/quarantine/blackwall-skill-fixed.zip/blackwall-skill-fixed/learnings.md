# Blackwall Learnings

> This file is automatically updated by Claude during retrospectives.
> Last updated: 2026-01-01

## Context Engineering Insights

### The Paradigm Shift (2025)
- **Prompt Engineering** = what you say to the model
- **Context Engineering** = what the model KNOWS when you say it
- Context is a finite resource with diminishing marginal returns
- "Agent failures aren't model failures - they're context failures"

### Key Components of Context
1. System prompts (role, rules, behavior)
2. User prompts (immediate tasks)
3. Conversation history/state
4. Long-term memory (vector stores, RAG)
5. Tool definitions and outputs
6. Examples (few-shot)
7. Environmental context (OS, directory structure, current time)
8. Guardrails and constraints

### Andrej Karpathy Wisdom
- LLM context window = RAM (working memory)
- LLM = CPU
- Context engineering = Operating system curation
- "The delicate art and science of filling the context window with just the right information for the next step"

## Autonomous Coding Patterns

### GPT-5/5.1 Three Core Reminders
1. **Persistence**: "Keep going until completely resolved"
2. **Tool-calling**: "Read files, don't guess"
3. **Planning**: "Plan extensively before each function call"

Result: 20% improvement on SWE-bench with just these three instructions.

### Claude 4.x Best Practices
- Encourage complete context usage
- Prevent over-engineering (especially Opus 4.5)
- "Only make changes directly requested or clearly necessary"
- Provide verification tools (Playwright MCP for testing)

### Cline System Message Insights
- 11,000 characters of structured tool-use format
- Two-mode system: Plan Mode + Act Mode
- Step-by-step confirmation prevents excessive tool use
- ALWAYS provide FULL file contents, never placeholders

## Technical Stack Learnings

### Framer Motion
- Spring physics: `stiffness: 100, damping: 30` for natural feel
- Use `layout` prop for smooth layout animations
- `layoutId` enables shared element transitions
- `AnimatePresence` required for mount/unmount animations

### Supabase Realtime
- Enable replication on tables before subscribing
- Always unsubscribe on component unmount
- Use filters to narrow update scope
- Debounce frequent updates to reduce re-rendering

### Thesys C1
- 2-line setup: `npm install @thesysai/genui-sdk @crayonai/react-ui`
- Stateful components communicate back to AI agent
- `onAction` prop handles form submissions, button clicks

### Cerebras/Super Ninja
- 3,000 tokens/second (20x faster than GPU solutions)
- Wafer-scale architecture eliminates memory bandwidth bottleneck
- 15-second API swap from OpenAI

## Design Philosophy

### Eden Aesthetic
- Dark mode: #0a0a0a base
- Grain texture overlay
- Backdrop blur: `bg-background/80 backdrop-blur-md`
- Font: serif for branding, sans for UI
- White/5 borders

### Polly Pockets Concept
- Compact worlds that open to reveal complexity
- Function-first beauty
- Real-time reconfiguration based on agent activity
- Multiple interconnected worlds

## Meta-Learnings

### What Makes Specs Succeed
1. Complete world context (everything agent needs)
2. Clear constraints without micromanaging
3. Verification tools for self-correction
4. Persistence instructions for long tasks
5. DX-first principles (easy setup, clear errors)

### What Makes Specs Fail
- Step-by-step hand-holding
- Excessive hedging language
- Alternative approaches (provide ONE clear path)
- Micro-management of implementation details

---

## Session Log

### 2026-01-01 - Deep Research Session
- Conducted 120+ source research on context engineering
- Discovered Claude Flow, Flow Nexus, ruv-swarm ecosystem
- Learned about Skills learning loops from YouTube research
- Identified Sublinear Time Solver as O(log n) scheduling optimization
- Ralph Loop: Force persistence framework for Claude Code
